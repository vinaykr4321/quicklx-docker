These files are example web service clients for the Iomad web service functions. 

Web services should be set up in the normal way described in the Moodle documentation. 

All the examples use the XML/RPC protocol and are written in PHP. They should be run
from the command line using the PHP CLI interpreter. The only setup is to put your
access token and the URL of your Moodle site in config.php (in this directory). 

They are provided as examples only. 
