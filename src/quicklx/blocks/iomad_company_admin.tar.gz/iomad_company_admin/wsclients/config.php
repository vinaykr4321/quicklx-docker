<?php

/// SETUP - NEED TO BE CHANGED
/// generate token in moodle admin:  http://iomad.dev/admin/settings.php?section=webservicetokens
$token = '0cb02d6a22de9554c5f646a2ebb144e0';
/// use your domain here:
$domainname = 'http://iomad.dev';